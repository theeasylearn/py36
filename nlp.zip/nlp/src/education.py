import re

def extract_education(doc):
    """Improved education extractor"""
    education = []
    text = doc.text
    
    # Better degree patterns
    degree_patterns = [
        r'(B\.?Tech|Bachelor|Master|M\.?Tech|MBA|BCA|MCA|BSc|MSc|PhD|Diploma)',
        r'(Engineering|Computer Science|Information Technology|Business Administration)'
    ]
    
    sentences = [sent.text.strip() for sent in doc.sents]
    
    for sent in sentences:
        if any(re.search(pattern, sent, re.I) for pattern in degree_patterns):
            # Try to extract year
            year_match = re.search(r'(19|20)\d{2}', sent)
            year = year_match.group() if year_match else None
            
            education.append({
                "degree": sent.strip(),
                "year": year
            })
    
    return education