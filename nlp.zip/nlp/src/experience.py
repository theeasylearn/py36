import re

def extract_experience(doc):
    """Improved experience extractor"""
    experience = []
    text = doc.text.lower()
    
    # Look for common experience section starters
    exp_section = False
    sentences = [sent.text.strip() for sent in doc.sents]
    
    for sent in sentences:
        lower_sent = sent.lower()
        
        if any(word in lower_sent for word in ["experience", "work history", "employment"]):
            exp_section = True
            continue
            
        if exp_section and len(sent) > 20:
            # Try to extract company and duration
            company = None
            duration = None
            
            # Simple company detection
            if "at " in lower_sent or "for " in lower_sent:
                company_match = re.search(r'(?:at|for)\s+([A-Za-z0-9\s&]+)', sent, re.I)
                if company_match:
                    company = company_match.group(1).strip()
            
            # Duration
            duration_match = re.search(r'(\d{4}|\d{1,2}/\d{4})\s*[-–]\s*(\d{4}|present|current)', sent, re.I)
            if duration_match:
                duration = duration_match.group()
            
            experience.append({
                "description": sent,
                "company": company,
                "duration": duration
            })
            
            if len(experience) >= 6:  # Limit results
                break
    
    return experience