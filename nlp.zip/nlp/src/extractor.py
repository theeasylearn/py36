# src/extractor.py

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from preprocess import preprocess_resume
from contact import extract_contact_info
from skills import extract_skills
from education import extract_education
from experience import extract_experience
from certification import extract_certifications


def extract_resume(text, filename=""):
    """Main resume extraction pipeline"""
    doc = preprocess_resume(text)
    
    result = {
        "filename": filename,
        "contact": extract_contact_info(doc),
        "skills": extract_skills(doc),
        "education": extract_education(doc),
        "experience": extract_experience(doc),
        "certifications": extract_certifications(doc),
        "extracted_at": "2026"
    }
    
    return result